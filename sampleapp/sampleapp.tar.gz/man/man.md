SAMPLECMD 1 "MAR 2019" "User Commands" ""
=======================================
<!-- md2man-roff man.md > samplecmd.1 -->

NAME
----

samplecmd - awesome sample app

SYNOPSIS
--------

samplecmd

AUTHOR AND COPYRIGHT
------

Copyright (c) 2019 Your, Name <sample@example.com> Released under the MIT License.
